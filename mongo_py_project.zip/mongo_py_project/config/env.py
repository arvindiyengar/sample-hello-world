import os
from dotenv import load_dotenv


load_dotenv()

# This is a singleton class that loads the configuration from the environment variables.
class Config:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(Config, cls).__new__(cls)
            cls._instance._load_config()
        return cls._instance

    def _load_config(self):

        # Database configuration
        self.db_host = os.getenv('DB_HOST', "XXXXXX")
        self.db_port = int(os.getenv('DB_PORT', 27017))
        self.db_user = os.getenv('DB_USER', "XXXXXX")
        self.db_password = os.getenv('DB_PASSWORD', "XXXX")
        self.db_name = os.getenv('DB_NAME', "sample_db")
        self.db_collection = os.getenv('DB_COLLECTION', "sample_collection")

        # SMTP configuration

        self.smtp_server = os.getenv('SMTP_SERVER')
        self.smtp_port = int(os.getenv('SMTP_PORT'))
        self.sender_email = os.getenv('SENDER_EMAIL')
        self.password = os.getenv('SENDER_PASSWORD')

        # Email configuration
        self.receiver_email = os.getenv('RECEIVER_EMAIL')