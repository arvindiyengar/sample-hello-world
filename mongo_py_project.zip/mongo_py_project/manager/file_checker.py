from config.env import Config
import os
import json
from common.error import FileAlreadyProcessed

config = Config()

class FileChecker():
    def __init__(self, file_path:str) -> None:
        self.file_path = file_path

    def _verify_if_new_file(self) -> bool:
        if not os.path.exists("./processed_files.txt"):
            # for first time execution
            open("./processed_files.txt", 'w').close()
            return True

        with open ("./processed_files.txt", 'r') as f:
            processed_files = f.readlines()
            processed_files = [file.strip() for file in processed_files]
            if self.file_path in processed_files:
                return False
            return True

    def check_file(self) -> bool:
        return os.path.exists(self.file_path)
    
    def load_dict(self) -> dict:
        with open(self.file_path) as f:
            return json.load(f)

    def update_processed_files(self):
        with open ("./processed_files.txt", 'a') as f:
            f.write(self.file_path + "\n")

