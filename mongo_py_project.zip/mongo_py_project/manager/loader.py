from config.env import Config
from manager.file_checker import FileChecker
from common.error import FileNotFound, FileAlreadyProcessed
from clients.db import mongo_connector
from clients.email import EmailClient


config = Config()

class MongoLoader():
    def __init__(self, file_path:str, force_mode: bool) -> None:
        self.file_checker = FileChecker(file_path)
        self.force_mode = force_mode
        self.db_client = mongo_connector.get_client()
        self.email_client = EmailClient()

    def pre_processor(self):
        if not self.file_checker.check_file():
            raise FileNotFound("JSON File not found")
        print(f'Checking if file: {self.file_checker.file_path} is already processed')
        if not self.file_checker._verify_if_new_file():
            print(f'JSON file processed already, checking for force mode')
            if not self.force_mode:
                print(f'Force mode not enabled')
                raise FileAlreadyProcessed("File already processed")
            else:
                print(f'Force mode enabled and hence processing the file')
        else:
            print(f'New JSON file found')

    def load_data_to_db(self, data: dict):
        db = self.db_client[config.db_name]
        collection = db[config.db_collection]
        collection.insert_many(data)

    def post_processor(self):
        self.file_checker.update_processed_files()
        # self.email_client.connect()
        # self.email_client.send_email("Data loaded successfully", "Data has been loaded to the database successfully")


    
    def execute(self):
        self.pre_processor()
        data = self.file_checker.load_dict()
        self.load_data_to_db(data)
        self.post_processor()
        
    
