class FileNotFound(Exception):
    def __init__(self, message: str) -> None:
        self.message = message
        super().__init__(self.message)

class FileAlreadyProcessed(Exception):
    def __init__(self, message: str) -> None:
        self.message = message
        super().__init__(self.message)

class DBNotCreated(Exception):
    def __init__(self, message: str) -> None:
        self.message = message
        super().__init__(self.message)
    
class DBCollectionNotCreated(Exception):
    def __init__(self, message: str) -> None:
        self.message = message
        super().__init__(self.message)