"""
Name: MongoLoader
Description: This module checkds for a file in the input folder and loads the data into the mongo database
Author: Pooja
Version: 0.0.1
Changelog:
- 0.0.1 : Initial version
"""
from manager.loader import MongoLoader
from common.error import FileNotFound, FileAlreadyProcessed
import datetime
import argparse

if __name__ == "__main__":
    print(f"Starting Mongoloader at :{datetime.datetime.now()}")
    parser = argparse.ArgumentParser(description="MongoLoader allows to read JSON files and insert to MongoDB")
    parser.add_argument('--file', type=str, required=True, help="Path to the file")
    parser.add_argument('--force', action='store_true', help="Force the file to be loaded if it's already present")

    args = parser.parse_args()
    try:
        
        loader = MongoLoader(file_path=args.file, force_mode=args.force)
        loader.execute()
    except FileAlreadyProcessed as e:
        print("Not processing the file as its already processed")
    except FileNotFound as e:
        print("No file found")
    except Exception as e:
        print(f"Error: {e}")
    print("Script execution completed")

