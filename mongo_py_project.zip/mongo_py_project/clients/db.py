
from pymongo import MongoClient
from config.env import Config
from common.error import DBCollectionNotCreated, DBNotCreated

config = Config()

class MongoConnector:
    _client_instance = None

    # creating a singleton class for mongo client
    def __new__(cls, *args, **kwargs):
        if cls._client_instance is None:
            cls._client_instance = super(MongoConnector, cls).__new__(cls, *args, **kwargs)
            cls._client_instance._initialize()
        return cls._client_instance

    def _initialize(self):
        self.client : MongoClient= MongoClient(config.db_host, config.db_port, username=config.db_user, password=config.db_password)

    def get_client(self):
        self.validate_db_collection()
        return self.client
    
    def validate_db_collection(self):
        db_list = self.client.list_database_names()
        if config.db_name not in db_list:
            raise DBNotCreated("DB not created")
        db = self.client[config.db_name]
        collection_list = db.list_collection_names()
        if config.db_collection not in collection_list:
            raise DBCollectionNotCreated("Collection not created")

    def insert_data(self, data: list[dict]):
        db = self.client[config.db_name]
        collection = db[config.db_collection]
        collection.insert_many(data)

mongo_connector = MongoConnector()