import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from config.env import Config

config = Config()

class EmailClient:
    _instance = None

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super(EmailClient, cls).__new__(cls, *args, **kwargs)
        return cls._instance

    def connect(self):
        try:
            self.server = smtplib.SMTP(config.smtp_server, config.smtp_port)
            self.server.starttls()
            self.server.login(config.sender_email, config.password)
            print("Connected to the email server successfully.")
        except Exception as e:
            print(f"Failed to connect to the email server: {e}")

    def send_email(self, subject, body):
        msg = MIMEMultipart()
        msg['From'] = config.sender_email
        msg['To'] = config.receiver_email
        msg['Subject'] = subject
        msg.attach(MIMEText(body, 'plain'))
        text = msg.as_string()
        self.server.sendmail(config.sender_email, config.receiver_email, text)

    def __del__(self):
        if hasattr(self, 'server'):
            self.server.quit()
