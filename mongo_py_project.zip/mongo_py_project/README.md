
# MongoLoader

MongoLoader is a Python utility that reads JSON files and inserts the data into a MongoDB database. It provides options to handle already processed files and force reprocessing if needed.

## Features

-   Read JSON files and insert data into MongoDB.
-   Handle already processed files to avoid duplicate processing.
-   Force reprocessing of files if required.

## Requirements

-   Python 3.x
-   `pymongo`  library
-   `python-dotenv`  library

## Installation

 - **Clone the repository**
	
	    git clone https://github.com/yourusername/mongoloader.git
	    cd  mongoloader
- **Create a virtual environment**

		python3  -m  venv  .venv
		source  .venv/bin/activate

- **Install the dependencies**

		pip  install  -r  requirements.txt

- **Create an .env file from the  .env.sample with appropriate values**

## Usage
To run the MongoLoader script, use the following command:

    python  main.py  --file  <path_to_json_file> [--force]

### Arguments

-   `--file`: Path to the JSON file to be processed (required).
-   `--force`: Force the file to be loaded even if it's already present (optional).
### Example

    python  main.py  --file  data.json  --force
